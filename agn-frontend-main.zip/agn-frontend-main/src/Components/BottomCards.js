// src/components/BottomCards.js
import './BottomCards.css';

const BottomCards = () => {
  return (
    <div className="bottom-cards">
      <div className="card blue">
        <h3>Are You Looking<br />For Loft Manager ?</h3>
        <p>We are committed to providing our customers with exceptional service.</p>
        <button>Get Started →</button>
      </div>
      <div className="card pink">
        <h3>Best place for<br />Pigeon race</h3>
        <p>We are committed to providing our customers with exceptional service.</p>
        <button>Get Started →</button>
      </div>
    </div>
  );
};

export default BottomCards;
