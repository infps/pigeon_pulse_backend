import './RaceTable.css';

const RaceTable = () => {
  return (
    <div className="race-table">
      <h3>UA Championship</h3>
      <table>
        <thead>
          <tr>
            <th>Rank</th>
            <th>Bird Name</th>
            <th>Band No</th>
            <th>Email</th>
            <th>Loft</th>
            <th>Arrival Time</th>
            <th>Speed (km)</th>
          </tr>
        </thead>
        <tbody>
          {[...Array(4)].map((_, i) => (
            <tr key={i}>
              <td>{`0${i + 1}`}</td>
              <td><strong>John Smith</strong></td>
              <td>CLD-A 123456</td>
              <td>abc@gmail.com</td>
              <td>54564{3 + i}</td>
              <td>10:4{5 + i} A.M</td>
              <td>22/09/2026</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="view-all">View All</p>
    </div>
  );
};

export default RaceTable;
