import './RaceCard.css';

const RaceCard = ({ status, title, image }) => {
  return (
    <div className="race-card">
      <div className="race-status">{status}</div>
      <img src={image} alt="Race" />
      <p>November 22, 2023 12:07 PM</p>
      <p>289 KM &nbsp; 673 Participant</p>
      <h4>{title}</h4>
      <button>Register Now</button>
    </div>
  );
};

export default RaceCard;
