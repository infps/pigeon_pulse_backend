import { Link } from "react-router-dom";
import "./Footer.css"; // Optional: extract relevant CSS if needed

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-top">
        <div className="newsletter">
          <input type="text" placeholder="Your email address" />
          <button>Sign Up</button>
        </div>
      </div>

      <div className="footer-columns">
        <div className="nav-links">
          <h5>Company</h5>
          <p>About Us</p>
          <p>Services</p>
          <p>FAQs</p>
          <p>
            <Link to={"/terms"}>Terms</Link>
          </p>
          <p>
            <Link to={"/contact"}>Contact Us</Link>
          </p>
        </div>
        <div>
          <h5>Quick Links</h5>
          <p>Get In Touch</p>
          <p>How it works</p>
        </div>
        <div>
          <h5>Popular Races</h5>
          {[...Array(7)].map((_, i) => (
            <p key={i}>Amsterdam VS USA</p>
          ))}
        </div>
        <div>
          <h5>Connect With Us</h5>
          <p>Facebook | Twitter | Instagram | LinkedIn</p>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© 2024 example.com. All rights reserved.</p>
        <p>Terms & Conditions | Privacy Notice</p>
      </div>
    </footer>
  );
};

export default Footer;
