import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => {
  return (
    <header className="navbar">
      <div className="logo">AGN</div>
      <nav className="nav-links">
        <Link to="/">Home</Link>
        <Link to="/live-tracking">Live Tracking</Link>
        <Link to="/upcomingraces">Races</Link>
        <Link to="/result">Result</Link>
        <Link to="/about">About</Link>
        <Link to="/contact">Contact Us</Link>
      </nav>
      <div className="auth-buttons">
        <Link to="/login">
          <button className="login-btn">Log In</button>
        </Link>
        <Link to="/signup">
          <button className="signup-btn">Sign Up</button>
        </Link>
      </div>
    </header>
  );
};

export default Header;
