// src/components/Sidebar.js
import { Link, useLocation } from 'react-router-dom';
import './Sidebar.css';

const Sidebar = () => {
  const location = useLocation();

  return (
    <div className="sidebar">
      <ul>
        <li className={location.pathname === '/contact' ? 'active' : ''}>
          <Link to="/contact">Contact Us</Link>
        </li>
        <li className={location.pathname === '/terms' ? 'active' : ''}>
          <Link to="/terms">Terms & Conditions</Link>
        </li>
        <li className={location.pathname === '/privacy' ? 'active' : ''}>
          <Link to="/privacy">Privacy Policy</Link>
        </li>
        <li className={location.pathname === '/refund' ? 'active' : ''}>
          <Link to="/refund">Refund Policy</Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
