import './FilterSearchBar.css';

const FilterSearchBar = () => {
  return (
    <div className="filter-search">
      <select>
        <option value="">Filter</option>
      </select>
      <input type="text" placeholder="Search" />
      <button><i className="fa fa-search"></i></button>
    </div>
  );
};

export default FilterSearchBar;
