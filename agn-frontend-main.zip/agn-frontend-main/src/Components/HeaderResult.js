import './HeaderResult.css';

const HeaderResult = () => {
  return (
    <div className="header">
      <h1>Chasing The Sky</h1>
      <p>One Feather At A Time</p>
      <img src="/assets/pigeon1.jpg" alt="Flying Pigeons" className="header-image" />
    </div>
  );
};

export default HeaderResult;
