import './RaceSidebar.css';

const RaceSidebar = () => {
  return (
    <div className="race-sidebar">
      <h4>Race Live Statistics</h4>
      <p>UA Championship</p>
      <ul>
        {[...Array(9)].map((_, i) => (
          <li key={i}>
            <strong>{`0${i + 1}`} John Smith</strong><br />
            <span>5456464</span> <span className="time">10:45 A.M</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RaceSidebar;
