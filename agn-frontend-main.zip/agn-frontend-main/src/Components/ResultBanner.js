import './ResultBanner.css';

const ResultBanner = () => {
  return (
    <div className="result-banner">
      <div className="banner-text">
        <h1>2025 Summer Championship Prize Pool<br />$2000</h1>
        <button>Register Now</button>
      </div>
      <div className="banner-img"></div>
    </div>
  );
};

export default ResultBanner;
