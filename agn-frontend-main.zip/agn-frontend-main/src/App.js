import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import About from './Pages/About';
import Contact from './Pages/Contact';
import Home from './Pages/Home';
import Login from './Pages/Login';
import Privacy from './Pages/Privacy';
import Refund from './Pages/Refund';
import Result from './Pages/Result';
import Signup from './Pages/Signup';
import Terms from './Pages/Terms';
import UpcomingRaces from './Pages/UpcomingRaces';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/terms" element={<Terms />} />
         <Route path="/signup" element={<Signup />} />
         <Route path="/login" element={<Login />} />
         <Route path="/contact" element={<Contact />} />
         <Route path="/terms" element={<Terms />} />
         <Route path="/privacy" element={<Privacy />} />
         <Route path="/refund" element={<Refund />} />
         <Route path="/result" element={<Result />} />
         <Route path="/upcomingraces" element={<UpcomingRaces />} />
      </Routes>
    </Router>
  );
}

export default App;
