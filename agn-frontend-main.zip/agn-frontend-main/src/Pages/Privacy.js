import BottomCards from '../Components/BottomCards';
import Footer from '../Components/Footer';
import Header from '../Components/Header';
import Sidebar from '../Components/Sidebar';
import './Terms.css'; // Reuse the same styling

const Privacy = () => {
  return (
    <div>
      <Header />
      <div className="terms-page">
        <Sidebar />
        <div className="terms-content">
          <h2>Privacy Policy</h2>
          <p>
            We value your privacy and are committed to protecting your personal information. This privacy policy outlines
            how we collect, use, and protect your data.
          </p>
          <p>
            Information is collected only for the purpose of improving your experience. We do not share or sell your data to
            third parties without your consent.
          </p>
          <p>
            Your data may include your name, contact information, and usage behavior which is secured with the latest encryption
            and safety standards.
          </p>
          <p>
            By using our services, you agree to this policy. We may update it occasionally and recommend reviewing this page
            periodically.
          </p>
        </div>
      </div>
      <BottomCards />
      <Footer />
    </div>
  );
};

export default Privacy;
