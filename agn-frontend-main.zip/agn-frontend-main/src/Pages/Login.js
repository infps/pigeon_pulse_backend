// src/Pages/Signup.js
import { Link } from 'react-router-dom';
import facebookIcon from '../images/Fsa.png';
import googleIcon from '../images/google.png'; // Add to /assets
import './Signup.css';

const Login = () => {
  return (
    <div className="signup-container">
      <div className="top-blue-bg"></div>

      <div className="top-bar">
        <div className="logo-section">
          <div className="logo-circle">AGN</div>
          <span className="logo-text">AGN</span>
        </div>
        <Link to="/signup" className="signin-btn">SIGN UP</Link>
      </div>

      <div className="form-box">
        <h2>Sign in to AGN</h2>
        <p className="subtitle">Quick & Simple way to Automate your payment</p>

        <form className="signup-form">
          
          <div className="form-group">
            <label>EMAIL ADDRESS</label>
            <input type="email" placeholder="johndoe@example.com" />
          </div>
          <div className="form-group">
            <label>PASSWORD</label>
            <div className="password-wrap">
              <input type="password" placeholder="************" />
              <span className="eye-icon">👁</span>
            </div>
          </div>
          

          <button type="submit" className="create-account-btn">CREATE AN ACCOUNT</button>
        </form>

        <div className="or-divider">OR</div>

        <div className="social-buttons">
          <button className="social-btn">
            <img src={googleIcon} alt="Google" />
          </button>
          <button className="social-btn">
            <img src={facebookIcon} alt="Facebook" />
          </button>
        </div>

        <p className="copyright">© 2021 - 2025 All Rights Reserved. Gpay</p>
      </div>
    </div>
  );
};

export default Login;
