import BottomCards from '../Components/BottomCards';
import FilterSearchBar from '../Components/FilterSearchBar';
import Footer from '../Components/Footer';
import Header from '../Components/Header'; // Global site header (navigation etc.)
import HeaderResult from '../Components/HeaderResult'; // Specific banner/header for results
import RaceCard from '../Components/RaceCard';
import './UpcomingRaces.css';

const races = [
  { status: 'Coming Soon', title: '2024 Pigeon Race Amsterdam VS USA', image: '/assets/pigeon1.jpg' },
  { status: 'Closing Soon', title: '2025 Pigeon Race Amsterdam VS USA', image: '/assets/pigeon2.jpg' },
  { status: 'Closing Soon', title: '2026 Pigeon Race Amsterdam VS USA', image: '/assets/pigeon2.jpg' },
  // Repeat until you have 12 items
];

const UpcomingRaces = () => {
  return (
    <>
      <Header />         {/* Global Navigation Header */}
      <HeaderResult />   {/* Result Page Banner Header */}

      <div className="main-content">
        <h2>Upcoming Races</h2>
        <FilterSearchBar />
        <div className="race-grid">
          {races.map((race, index) => (
            <RaceCard key={index} {...race} />
          ))}
        </div>
      </div>
      <BottomCards />
      <Footer />
    </>
  );
};

export default UpcomingRaces;
