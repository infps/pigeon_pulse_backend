import BottomCards from '../Components/BottomCards';
import Footer from '../Components/Footer';
import Header from '../Components/Header';
import Sidebar from '../Components/Sidebar';
import './Terms.css';

const Terms = () => {
  return (
    <div>
      <Header />
      <div className="terms-page">
        <Sidebar />
        <div className="terms-content">
          <h2>Terms & Conditions</h2>
          <p>
            Lorem ipsum dolor sit amet consectetur. Odio ultrices odio vulputate vel turpis accumsan ante interdum tristique. 
            Facilisis leo facilisis eu pharetra. Ante netus elit amet ut vitae dapibus. Placerat ut blandit elementum hendrerit 
            netus nullam aenean venenatis. Facilisi vel leo vitae amet elit cursus mauris semper a. Proin gravida et tempor 
            fusce nibh vestibulum neque sed quis. Est leo mauris turpis ultrices placerat cras molestie nisl...
          </p>
          <p>
            Tincidunt tellus arcu nunc quis sed nec. Duis nibh hendrerit ipsum lectus odio. Mi ornare nisl diam diam cursus. 
            Amet vel et sodales ante pretium morbi pulvinar vel sapien. Pretium laoreet condimentum sed tortor et eget eu 
            volutpat sodales. A cursus bibendum nulla vel proin...
          </p>
        </div>
      </div>
      <BottomCards />
      <Footer />
    </div>
  );
};

export default Terms;
