import BottomCards from '../Components/BottomCards';
import Footer from '../Components/Footer';
import Header from '../Components/Header';
import RaceSidebar from '../Components/RaceSidebar';
import RaceTable from '../Components/RaceTable';
import ResultBanner from '../Components/ResultBanner';
import './Result.css';

const Result = () => {
  return (
    <div className="result-page">
      <Header />
      <ResultBanner />

      <div className="result-content">
        <RaceSidebar />
        <div className="table-section">
          <input
            className="race-search"
            type="text"
            placeholder="🔍 Search Race Name..."
          />

          <RaceTable />
          <RaceTable />
        </div>
      </div>
      <BottomCards />
      <Footer />
    </div>
  );
};

export default Result;
