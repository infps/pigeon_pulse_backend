
const About = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>About Us</h1>
      <p>This is the About page.</p>
    </div>
  );
};

export default About;
