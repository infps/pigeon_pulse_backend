// src/Pages/Home.js
import BottomCards from '../Components/BottomCards';
import Footer from '../Components/Footer';
import Header from '../Components/Header';
import './Home.css';

const Home = () => {
  return (
    <main className="home-container">
      <Header />

      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <h1>TRACK <span>PIGEONS</span></h1>
          <h2>WATCH LIVE RESULTS</h2>
          <p>Experience the thrill of pigeon racing with real-time tracking and live results from competitions around the world.</p>
          <div className="hero-buttons">
            <button className="btn-primary">Register Loft</button>
            <button className="btn-secondary">Join As Race Manager</button>
          </div>
        </div>
        <div className="hero-image"></div>
      </section>

      {/* Carousel */}
      <section className="carousel-section">
        <h3>Win Pedigree</h3>
        <div className="carousel">
          {[...Array(7)].map((_, i) => (
            <div className="carousel-item" key={i}>
              <div className="carousel-img"></div>
            </div>
          ))}
        </div>
      </section>

      {/* Upcoming Races */}
      <section className="races-section">
        <h3>Upcoming Races</h3>
        <div className="races">
          {[2024, 2025, 2026].map((year, idx) => (
            <div className="race-card" key={idx}>
              <div className={`race-img race-img-${year}`}></div>
              <div className="race-info">
                <p>November 22, 2023 12:07 PM</p>
                <p>998 KM | 673 Participants</p>
                <h4>{year} Pigeon Race Amsterdam VS USA</h4>
                <button className="btn-secondary">Register Now</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Live Races */}
      <section className="live-races">
        <div className="live-img"></div>
        <div className="live-info">
          <h3>Live Pigeon Races</h3>
          <ul>
            <li>We are the UK's largest provider</li>
            <li>You get 24/7 roadside assistance</li>
            <li>We fix 4 out of 5 cars at the roadside</li>
          </ul>
        </div>
      </section>

      {/* Stats */}
      <section className="stats">
        <div className="stat-item"><h4>836M</h4><p>Total Race</p></div>
        <div className="stat-item"><h4>738M</h4><p>Total Loft Manager</p></div>
        <div className="stat-item"><h4>100M</h4><p>Races Per Day</p></div>
        <div className="stat-item"><h4>238M</h4><p>Today Race</p></div>
      </section>

      {/* CTA */}
      <section className="cta-banner">
        <h2>TRACK <span>PIGEONS</span> WATCH LIVE RESULTS</h2>
        <button className="btn-primary">View Previous Races</button>
      </section>

       <BottomCards />

      <Footer />
    </main>
  );
};

export default Home;
