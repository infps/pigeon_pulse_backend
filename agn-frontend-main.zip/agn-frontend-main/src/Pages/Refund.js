import BottomCards from '../Components/BottomCards';
import Footer from '../Components/Footer';
import Header from '../Components/Header';
import Sidebar from '../Components/Sidebar';
import './Terms.css'; // Reuse the same CSS

const Refund = () => {
  return (
    <div>
      <Header />
      <div className="terms-page">
        <Sidebar />
        <div className="terms-content">
          <h2>Refund Policy</h2>
          <p>
            Our refund policy is designed to ensure transparency and fairness. If you are not satisfied with your experience,
            you may be eligible for a refund based on the terms outlined below.
          </p>
          <p>
            Refunds are only processed for transactions that meet the required conditions and are requested within the eligible time frame.
            We do not entertain refund requests made after 7 days from the date of service or delivery.
          </p>
          <p>
            To initiate a refund, please contact our support team with your transaction details and a valid reason. Once reviewed,
            eligible refunds will be processed within 5–7 business days.
          </p>
          <p>
            We reserve the right to decline refunds if the conditions are not met or in cases of policy abuse.
          </p>
        </div>
      </div>
      <BottomCards />
      <Footer />
    </div>
  );
};

export default Refund;
