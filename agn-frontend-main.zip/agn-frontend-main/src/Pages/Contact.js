// src/Pages/Contact.js
import BottomCards from '../Components/BottomCards';
import Footer from '../Components/Footer';
import Header from '../Components/Header';
import './Contact.css';

const Contact = () => {
  return (
    <>
      <Header />

      <div className="contact-page">
        {/* Top Header Section */}
        <div className="header-section">
          <div className="header-overlay">
            <h1>Contact Us</h1>
          </div>
        </div>

        {/* Contact Section */}
        <div className="contact-container">
          <div className="contact-info">
            <h2>Let's talk with us</h2>
            <p>Questions, comments, or suggestions? Simply fill in the form and we’ll be in touch shortly.</p>
            <ul>
              <li>
                📍 <strong>1055 Arthur ave Elk Groot, 67. <br /> New Palmas South Carolina.</strong>
              </li>
              <li>📞 +1 234 678 9108 99</li>
              <li>✉️ Contact@moralizer.com</li>
            </ul>
          </div>

          {/* Contact Form */}
          <div className="contact-form">
            <form>
              <div className="form-row">
                <input type="text" placeholder="First Name*" />
                <input type="text" placeholder="Last Name*" />
              </div>
              <input type="email" placeholder="Email*" />
              <input type="text" placeholder="Phone Number*" />
              <textarea placeholder="Your message..." rows="4"></textarea>
              <button type="submit">Send Message</button>
            </form>
          </div>
        </div>
      </div>

      {/* Reusable Bottom Cards */}
      <BottomCards />

      <Footer />
    </>
  );
};

export default Contact;
